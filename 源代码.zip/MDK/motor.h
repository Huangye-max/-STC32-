#ifndef __motor_H_
#define __motor_H_
//extern uint16  dat;
//extern uint16  dat2;
extern	int out_you; 
extern	int out_zuo;
extern	void motor_out();
extern	void R_motor_out();
extern	void L_motor_out();
extern  void motor_init();
extern  int v;

#endif