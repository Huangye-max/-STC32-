#ifndef __XIANSHI_H_
#define __XIANSHI_H_
extern void xianshiqt();
extern void anjian();
extern void shaocha();




#endif