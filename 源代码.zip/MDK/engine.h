#ifndef __engine_H_
#define __engine_H_
extern void SEngine_out();
extern uint32 SE_Center_Value ;
extern uint32 SE_Value ;
extern void SEngine_pwm(int16 sepwm_data);
extern float p;
extern float d;
extern void chaomifen();


#endif